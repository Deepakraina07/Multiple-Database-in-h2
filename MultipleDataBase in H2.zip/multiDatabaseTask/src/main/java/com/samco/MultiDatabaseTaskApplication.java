package com.samco;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.samco.book.model.Book;
import com.samco.book.repository.BookRepository;
import com.samco.user.model.User;
import com.samco.user.repository.UserRepository;

@SpringBootApplication
@RestController

public class MultiDatabaseTaskApplication {

	@Autowired
	UserRepository userRepository;
	
	@Autowired
	BookRepository bookRepository;
	
	//User 
	@PostMapping("/addUser")
	public User addUser(@RequestBody User user) {
		return userRepository.save(user);
	}
	
	@GetMapping("/getUser")
	public List<User> getUser(){
		return userRepository.findAll(); 
	}
	
	@GetMapping("/getUser/{id}")
	public Optional<User> getById(@PathVariable("id") int id) {
		return userRepository.findById(id);	
	}
	
	
	@PutMapping("/updateUser")
	public User update(@RequestBody User user) {
		return userRepository.save(addUser(user));
	}
	 
	
	@DeleteMapping("/deleteUser")
	public void deleteAll(@PathVariable("id") User user) {
		userRepository.delete(user);
	}
	
	@DeleteMapping("/deleteUser/{id}")
	public void deleteById(@PathVariable("id") int id) {
		 userRepository.deleteById(id);
	}
	
	//Book
	@PostMapping("/addBook")
	public Book addBook(@RequestBody Book book) {
		return bookRepository.save(book);
	}
	
	@GetMapping("/getBook")
	public List<Book> getBook(){
		return bookRepository.findAll();
	}
	
	@GetMapping("/getBook/{id}")
	public Optional<Book> getBookById(@PathVariable("id") int id) {
		return bookRepository.findById(id);	
	}
	
	@PutMapping("/updateBook")
	public Book updateBook(@RequestBody Book book) {
		return bookRepository.save(addBook(book));
	}
	
	@DeleteMapping("/deleteBook")
	public void deleteBook(@PathVariable Book book) {
		bookRepository.delete(book);
	}
	
	@DeleteMapping("/deleteBook/{id}")
	public void deleteByBook(@PathVariable("id") int id) {
		bookRepository.deleteById(id);
	}
	
	public static void main(String[] args) {
		SpringApplication.run(MultiDatabaseTaskApplication.class, args);
		System.out.println("Server Created Successfully");
	}

}
