package com.samco.book.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.samco.book.model.Book;

public interface BookRepository extends JpaRepository<Book, Integer>{

}
